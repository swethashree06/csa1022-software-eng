# CSA10 – Software Engineering: Lab Experiments

**Saveetha School of Engineering · Saveetha Institute of Medical and Technical Sciences**
Department of Computer Science Engineering

A single repository containing the work for all **25 lab experiments** of the CSA10 Software Engineering course.
Each experiment lives in its own folder (`exp-NN-<name>/`) with a `README.md` (aim, tools, procedure, expected output)
plus whatever source code, configuration, scripts or templates the experiment needs.

## Experiments

| Sl. No | Experiment | Tools used | CO |
|---|---|---|---|
| 1 | [Create a Kanban board (To Do / In-Progress / Done) with 5+ tasks and move them across columns](exp-01-kanban-board/) | Jira or Trello | CO1 |
| 2 | [Sketch a simple prototype of a Bus Ticket Booking System](exp-02-figma-bus-ticket-prototype/) | Figma | CO1 |
| 3 | [E-commerce mobile app prototype to resolve conflicting stakeholder views on UI](exp-03-figma-ecommerce-prototype/) | Figma | CO1 |
| 4 | [Scrum project in Jira: backlog (5+ items), prioritise, 1-week sprint, start/end board screenshots](exp-04-jira-scrum-project/) | Jira | CO2 |
| 5 | [Library Management System requirements categorised with MoSCoW (Google Sheet / Excel)](exp-05-library-moscow/) | Google Sheet or Excel | CO2 |
| 6 | [Link Jira tasks with Confluence for the Library Management System](exp-06-jira-confluence-integration/) | Jira & Confluence | CO2 |
| 7 | [Task Management System requirements prioritised with MoSCoW and Kano](exp-07-task-management-moscow-kano/) | Jira | CO2 |
| 8 | [Online Learning Platform requirements prioritised with MoSCoW and Kano](exp-08-online-learning-moscow-kano/) | Jira | CO2 |
| 9 | [Collaborate on GitHub using the fork-and-pull-request workflow](exp-09-fork-and-pull-request/) | Git/GitHub | CO3 |
| 10 | [Work with Git branches and resolve merge conflicts](exp-10-branching-and-merge-conflicts/) | Git/GitHub | CO3 |
| 11 | [Static website containerised, built and served with Docker (Nginx)](exp-11-docker-static-website/) | Docker | CO3 |
| 12 | [Flask API: containerise, push to Docker Hub, deploy on Kubernetes (NodePort)](exp-12-flask-docker-kubernetes/) | Docker & Kubernetes | CO3 |
| 13 | [CI/CD pipeline with Jenkins for a containerised application](exp-13-jenkins-ci-cd/) | Docker | CO4 |
| 14 | [Continuous Deployment of a Dockerised app using GitHub Actions](exp-14-github-actions-cd/) | GitHub Actions, Docker | CO3 |
| 15 | [GitHub repository and version control for a team project](exp-15-github-team-version-control/) | Git/GitHub | CO3 |
| 16 | [Containerise a Python Flask To-Do application with Docker](exp-16-docker-flask-todo/) | Docker, Flask | CO3 |
| 17 | [Push and pull Docker images using Docker Hub](exp-17-docker-hub-push-pull/) | Docker Hub, Docker CLI | CO3 |
| 18 | [Multi-container (frontend, backend, database) application on Kubernetes](exp-18-kubernetes-multi-container/) | Docker, Kubernetes | CO3 |
| 19 | [CI/CD pipeline with GitHub Actions for a containerised Flask app](exp-19-github-actions-ci-cd-flask/) | GitHub Actions, Docker | CO3 |
| 20 | [Create a GitHub repo, clone it, edit README.md, commit and push](exp-20-github-repo-readme-push/) | Git/GitHub | CO3 |
| 21 | [Clone an existing repository and make a small change](exp-21-clone-and-edit/) | Git/GitHub | CO3 |
| 22 | [Modify a file in a cloned repo, commit locally and push to GitHub](exp-22-commit-and-push/) | Git/GitHub | CO4 |
| 23 | [Pull a collaborator's latest changes to keep your clone up to date](exp-23-pull-latest-changes/) | Git/GitHub | CO4 |
| 24 | [Create the feature-login branch, add login.py and open a pull request](exp-24-feature-login-branch/) | Git/GitHub | CO4 |
| 25 | [Fork, clone, branch, implement a feature and submit a pull request upstream](exp-25-fork-feature-branch-pr/) | Git/GitHub | CO4 |

## Repository layout

```
.
├── exp-01-… … exp-25-…     one folder per experiment
├── .github/workflows/        CI for this repo + the CD pipelines of Exp 14 and Exp 19
├── scripts/                  helpers (run every offline demo, run every test)
├── docs/                     screenshot checklist and submission notes
└── Makefile                  `make test`, `make demos`
```

## What is real vs. what you must capture yourself

| Kind | Experiments | What's in the repo |
|---|---|---|
| **Runnable code** | 11, 12, 13, 14, 16, 17, 18, 19, 24 | Source, Dockerfiles, Kubernetes manifests, Jenkinsfile, GitHub Actions workflows, unit tests |
| **Runnable Git demos** | 9, 10, 20–23, 25 | `demo.sh` that replays the whole exercise locally using bare repos as "GitHub" (no account/network needed) |
| **Spreadsheets** | 5, 7, 8 | `.xlsx` + `.csv` with every requirement categorised and justified |
| **Tool-based (Jira / Trello / Figma / Confluence)** | 1, 2, 3, 4, 6 | Import-ready data, SVG wireframes, page templates and a step-by-step guide. The tools are SaaS, so **screenshots must be taken by you** – see [`docs/screenshots-checklist.md`](docs/screenshots-checklist.md) |

Steps that need your own accounts (Docker Hub, GitHub, a cloud platform, Jira) are documented in each README and
use placeholders such as `YOUR_DOCKERHUB_USER`.

## Quick start

```bash
make test     # unit tests for every Python app
make demos    # replay all offline Git exercises in a throw-away sandbox
```

Requirements: Git ≥ 2.28, Python ≥ 3.10 (`pip install -r requirements-dev.txt`), optionally Docker and kubectl.

## Suggested Git history (how this repo is organised)

`main` is protected; every experiment is added through a short-lived branch `exp/NN-<name>` and a pull request,
which mirrors the workflow practised in Experiments 9, 10, 15, 24 and 25. See [CONTRIBUTING.md](CONTRIBUTING.md).
