## Summary
<!-- What does this change do and why? -->

## Experiment / module
<!-- e.g. Exp 12 – Flask + Kubernetes -->

## Checklist
- [ ] Tests pass locally (`make test`)
- [ ] README of the experiment updated
- [ ] No secrets committed
- [ ] Reviewer assigned
