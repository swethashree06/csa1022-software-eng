# Screenshot checklist

Tools like Jira, Trello, Figma, Confluence, Docker Hub and GitHub are web services, so their screenshots must be
taken from **your** accounts. Save each image in the experiment's `screenshots/` folder using the suggested name.

| Exp | Screenshots to capture |
|---|---|
| 1 | `01-board-initial.png`, `02-board-in-progress.png`, `03-board-done.png` |
| 2 | `01-figma-frames.png`, `02-figma-prototype-flow.png` |
| 3 | `01-figma-frames.png`, `02-stakeholder-comments.png` |
| 4 | `01-backlog.png`, `02-sprint-start-board.png`, `03-sprint-end-board.png` |
| 5, 7, 8 | Optional – the `.xlsx` is the deliverable. For 7/8 add `jira-labels-board.png` |
| 6 | `01-confluence-page.png` (Jira macro + progress bar) |
| 9, 25 | `01-fork.png`, `02-pull-request.png`, `03-review-comments.png`, `04-merged.png` |
| 10 | `01-conflict-markers.png`, `02-resolved.png`, `03-pr-merged.png` |
| 11 | `01-docker-build.png`, `02-docker-run.png`, `03-browser.png` |
| 12 | `01-docker-push.png`, `02-kubectl-get-all.png`, `03-curl-nodeport.png` |
| 13 | `01-jenkins-pipeline-stages.png`, `02-webhook-trigger.png` |
| 14, 19 | `01-actions-run-green.png`, `02-registry-image.png`, `03-deployed-app.png` |
| 15 | `01-branches.png`, `02-pr-review.png`, `03-network-graph.png` |
| 16 | `01-docker-run.png`, `02-curl-tests.png`, `03-docker-hub.png` |
| 17 | `01-tag-push.png`, `02-pull-run-on-other-machine.png` |
| 18 | `01-kubectl-get-pods.png`, `02-scale.png`, `03-dashboard.png` |
| 20–24 | Terminal output of each step + the GitHub web page showing the result |
